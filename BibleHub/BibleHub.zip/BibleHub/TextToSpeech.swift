//
//  TextToSpeech.swift
//  BibleHub
//
//  Created by Turma01-8 on 25/04/24.
//

import SwiftUI
import AVFoundation


struct TextToSpeech: View {
    
    @State  var inputString = "Hello world! My name is Dev Techie"
    var body: some View {
        
        Button(/*@START_MENU_TOKEN@*/"Button"/*@END_MENU_TOKEN@*/) {
            /*@START_MENU_TOKEN@*//*@PLACEHOLDER=Action@*/ /*@END_MENU_TOKEN@*/
        }
        
    }
}

#Preview {
    TextToSpeech()
}
