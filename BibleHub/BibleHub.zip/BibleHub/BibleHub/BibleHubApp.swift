//
//  BibleHubApp.swift
//  BibleHub
//
//  Created by Turma01-8 on 18/04/24.
//

import SwiftUI

@main
struct BibleHubApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
