//
//  Versiculos.swift
//  BibleHub
//
//  Created by Turma01-8 on 22/04/24.
//

import SwiftUI
var backgroundGradient3 = LinearGradient(
    colors: [Color.cyan,Color.white,Color.cyan],
    startPoint: .top, endPoint: .bottom)

struct Versiculos: View {
    var body: some View {
        ZStack{backgroundGradient2
            .ignoresSafeArea()
            VStack {
                HStack{
                    Image("biblehub-transformed")
                        .resizable()
                        .frame(width: 350, height: 100)
                }
                Spacer()
                ScrollView{
                    
                }
            }
        }
    }
}

//#Preview {
//    Versiculos()
//}
