//
//  Autores.swift
//  BibleHub
//
//  Created by Turma01-8 on 18/04/24.
//

import SwiftUI

var backgroundGradient2 = LinearGradient(
    colors: [Color.cyan,Color.white,Color.cyan],
    startPoint: .top, endPoint: .bottom)

class Pesquisar: ObservableObject{
    @Published var livro = String()
    @Published var capitulo = String()
}


struct Autores: View {
    var testamento: [biblia]
    @StateObject var viewmodel = ViewModel()
    @State private var boleana = false
    let colums = [GridItem(.flexible()),GridItem(.flexible()),GridItem(.flexible()),GridItem(.flexible()),GridItem(.flexible())]
    @State var capitulo : Int = 50
    var body: some View {
        NavigationStack{
            ZStack{backgroundGradient2
                .ignoresSafeArea()
                VStack {
                    HStack{
                        Image("biblehub-transformed")
                            .resizable()
                            .frame(width: 350, height: 100)
                    }
                    Spacer()
                    ScrollView{
                        VStack{
                            
                            ForEach(testamento, id: \.self){ index in
                                
                                
                                VStack{
                                    Text("\(index.name!)" + "\(index.chapters!)" )
                                        .font(.title)
                                        .bold()
                                    Spacer()
                                    
                                }.onTapGesture {
                                    capitulo = index.chapters!
//                                    Pesquisar().livro = index.abbrev.pt!
                                    boleana.toggle()
                                    
                                }.sheet(isPresented: $boleana) {
                                    NavigationStack{
                                        LazyVGrid(columns: colums){
                                            ForEach(1...capitulo , id: \.self ) { chap in
                                                NavigationLink(destination: Versiculos()){
                                                    Text("\(chap)")
                                                    
                                                }
                                            }
                                        }
                                    }
                                    
                                }
                                
                            }
                        }
                    
                    }
                }
                .onAppear(){
                    viewmodel.fetchBiblia()
                }
            }
        }
    }
}

//#Preview {
//    Autores()
//}
